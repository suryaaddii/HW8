const express = require('express');
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('database', 'username', 'password', {
  dialect: 'mysql',
  host: 'localhost',
});

const app = express();

// Model Actor
const Actor = sequelize.define('Actor', {
  name: DataTypes.STRING,
  birthday: DataTypes.DATE,
  age: DataTypes.INTEGER, // Tambahkan kolom age
});

// Model Film
const Film = sequelize.define('Film', {
  title: DataTypes.STRING,
  categoryId: DataTypes.INTEGER,
});

// Routing untuk pertanyaan-pertanyaan yang diminta
app.get('/films', async (req, res) => {
  const films = await Film.findAll();
  res.json(films);
});

app.get('/film/:id', async (req, res) => {
  const { id } = req.params;
  const film = await Film.findByPk(id);
  res.json(film);
});

app.get('/categories', async (req, res) => {
  // Implementasi untuk mendapatkan list category
});

app.get('/films/category/:categoryId', async (req, res) => {
  // Implementasi untuk mendapatkan list film berdasarkan category
});

app.listen(3000, () => {
  console.log('Server berjalan di http://localhost:3000');
});
